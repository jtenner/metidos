#!/usr/bin/env python3
"""Risk gate for Kraken-style order intents.

Reads JSON from stdin:
{
  "order_intent": {...},
  "account": {"equity": 10000, "daily_realized_pnl": -20, "open_positions": [], "open_orders": []},
  "policy": {...}
}
"""

from __future__ import annotations

import json
import sys
from decimal import Decimal
from typing import Any


def D(x: Any, default: str = "0") -> Decimal:
    if x is None:
        return Decimal(default)
    return Decimal(str(x))


def risk_gate(payload: dict[str, Any]) -> dict[str, Any]:
    reasons: list[str] = []
    actions: list[str] = []
    intent = payload.get("order_intent", payload)
    account = payload.get("account", {})
    policy = payload.get("policy", {})

    mode = intent.get("mode", "paper")
    if mode == "live" and not bool(policy.get("live_trading_enabled", False)):
        reasons.append("live mode requested but live_trading_enabled is false")
        actions.append("enable live mode only after paper gate and human approval")

    if bool(policy.get("kill_switch_latched", False)):
        reasons.append("kill switch is latched")
        actions.append("manual reset required")

    equity = D(account.get("equity"))
    if equity <= 0:
        return {
            "approved": False,
            "reasons": ["account equity must be available and > 0"],
            "metrics": {},
            "required_actions_before_resubmission": ["provide account equity"],
        }

    side = intent.get("side")
    entry = D(intent.get("limit_price", intent.get("entry_price")))
    stop = D(intent.get("invalidation_price"))
    qty = D(intent.get("quantity"))
    fee_bps = D(intent.get("fee_bps_estimate", policy.get("taker_fee_bps_estimate", 0)))
    slippage_bps = D(intent.get("slippage_bps_estimate", policy.get("extra_slippage_bps_estimate", 0)))

    if side not in {"buy", "sell"}:
        reasons.append("side must be buy or sell")
    if entry <= 0:
        reasons.append("entry/limit price must be > 0")
    if stop <= 0:
        reasons.append("invalidation price must be > 0")
    if qty <= 0:
        reasons.append("quantity must be > 0")

    allowed_symbols = set(policy.get("allowed_symbols", policy.get("symbols", {}).get("allowed", [])) or [])
    symbol = intent.get("symbol")
    if allowed_symbols and symbol not in allowed_symbols:
        reasons.append(f"symbol {symbol!r} is not in allowed_symbols")

    allowed_order_types = set(policy.get("allowed_order_types", policy.get("orders", {}).get("allowed_order_types", ["limit"])) or ["limit"])
    order_type = intent.get("order_type", "limit")
    if order_type not in allowed_order_types:
        reasons.append(f"order_type {order_type!r} not allowed")

    if order_type == "market" and not bool(policy.get("allow_market_orders", policy.get("orders", {}).get("allow_market_orders", False))):
        reasons.append("market orders are disabled by policy")

    if bool(intent.get("leverage", False)) or D(intent.get("leverage_multiplier", 1)) > 1:
        if not bool(policy.get("allow_leverage", policy.get("exchange", {}).get("allow_leverage", False))):
            reasons.append("leverage requested but policy forbids leverage")

    if reasons:
        return {
            "approved": False,
            "reasons": reasons,
            "metrics": {},
            "required_actions_before_resubmission": actions or ["correct invalid order intent"],
        }

    if side == "buy":
        if stop >= entry:
            reasons.append("buy invalidation price must be below entry")
        per_unit_loss = entry - stop
    else:
        if stop <= entry:
            reasons.append("sell invalidation price must be above entry")
        per_unit_loss = stop - entry

    estimated_costs = qty * entry * (fee_bps + slippage_bps) / Decimal("10000")
    loss_at_invalidation = qty * per_unit_loss + estimated_costs
    risk_fraction = loss_at_invalidation / equity
    notional = qty * entry
    position_notional_fraction = notional / equity

    max_risk = D(policy.get("max_risk_per_trade_fraction", policy.get("risk", {}).get("max_risk_per_trade_fraction", "0.0025")))
    max_notional_fraction = D(policy.get("max_position_notional_fraction", policy.get("risk", {}).get("max_position_notional_fraction", "0.02")))
    max_daily_loss_fraction = D(policy.get("max_daily_loss_fraction", policy.get("risk", {}).get("max_daily_loss_fraction", "0.01")))
    max_weekly_loss_fraction = D(policy.get("max_weekly_loss_fraction", policy.get("risk", {}).get("max_weekly_loss_fraction", "0.03")))

    if risk_fraction > max_risk:
        reasons.append(f"risk_fraction {risk_fraction:.8f} exceeds max {max_risk}")
        actions.append("reduce quantity or use a tighter valid invalidation price")
    if position_notional_fraction > max_notional_fraction:
        reasons.append(f"position_notional_fraction {position_notional_fraction:.8f} exceeds max {max_notional_fraction}")
        actions.append("reduce quantity")

    daily_pnl = D(account.get("daily_realized_pnl", 0))
    weekly_pnl = D(account.get("weekly_realized_pnl", 0))
    if daily_pnl <= -(equity * max_daily_loss_fraction):
        reasons.append("daily loss limit already breached")
        actions.append("halt trading for the day")
    if weekly_pnl <= -(equity * max_weekly_loss_fraction):
        reasons.append("weekly loss limit already breached")
        actions.append("halt trading for the week")
    if daily_pnl - loss_at_invalidation <= -(equity * max_daily_loss_fraction):
        reasons.append("trade could breach daily loss limit at invalidation")
        actions.append("reduce risk or wait for next session")

    max_open_orders = int(policy.get("max_open_orders", policy.get("account", {}).get("max_open_orders", 3)))
    if len(account.get("open_orders", []) or []) >= max_open_orders:
        reasons.append("max open orders already reached")
        actions.append("cancel stale orders before resubmission")

    metrics = {
        "equity": float(equity),
        "entry_price": float(entry),
        "invalidation_price": float(stop),
        "quantity": float(qty),
        "notional": float(notional),
        "estimated_costs": float(estimated_costs),
        "loss_at_invalidation": float(loss_at_invalidation),
        "risk_fraction": float(risk_fraction),
        "max_risk_fraction": float(max_risk),
        "position_notional_fraction": float(position_notional_fraction),
        "max_position_notional_fraction": float(max_notional_fraction),
        "daily_realized_pnl": float(daily_pnl),
        "weekly_realized_pnl": float(weekly_pnl),
    }

    return {
        "approved": not reasons,
        "reasons": reasons,
        "metrics": metrics,
        "required_actions_before_resubmission": actions,
    }


def main() -> int:
    payload = json.load(sys.stdin)
    result = risk_gate(payload)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["approved"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
