# Metidos Kraken Trading Skills

A portable skill pack for agents that interact with Kraken-style trading infrastructure.

This pack is intentionally **risk-first**. It does not contain profitable signals, buy/sell recommendations, or a promise of better returns. It gives your agents operational discipline: data validation, paper trading, risk limits, execution checks, journaling, reconciliation, security, and kill-switch behavior.

The default posture is:

- **Paper mode only**
- **No withdrawals**
- **No leverage**
- **No market orders**
- **No live trade unless every gate approves**
- **No single agent may both invent and execute a trade**
- **When state is uncertain, stop trading**

## Contents

```text
metidos-kraken-trading-skills/
├── skills/                  # Agent Skills, each with SKILL.md
├── config/                  # Risk and runtime policy templates
├── schemas/                 # JSON schemas for signals, orders, risk decisions, journals
├── examples/                # Orchestration prompts and sample JSON payloads
├── tests/                   # Lightweight tests for reference scripts
├── scripts/                 # Pack-level validation utility
├── README.md
├── INSTALL.md
├── METIDOS_ADAPTER_NOTES.md
├── MANIFEST.yaml
├── DISCLAIMER.md
└── SOURCES.md
```

## Recommended agent hierarchy

```text
Research Agent
  proposes strategy hypotheses and candidate signals
        ↓
Backtest / Paper Agent
  validates with fees, spread, slippage, partial fills, failed cancels
        ↓
Risk Manager Agent
  rejects unsafe size, missing stop, bad drawdown, bad exposure
        ↓
Market Data Integrity Agent
  rejects stale, desynchronized, wide-spread, shallow-depth markets
        ↓
Execution Guard Agent
  converts approved intent into safe limit-order workflow
        ↓
Reconciliation Agent
  compares local state to Kraken/exchange state after every event
        ↓
Journal / Review Agent
  writes immutable evidence for every decision
        ↓
Kill Switch
  overrides everything
```

## Activation order

For a trade candidate, activate these skills in order:

1. `kraken-trading-governance`
2. `kraken-strategy-research`
3. `kraken-paper-trading`
4. `kraken-market-data-integrity`
5. `kraken-liquidity-spread-filter`
6. `kraken-position-sizing`
7. `kraken-risk-manager`
8. `kraken-fee-edge-check`
9. `kraken-execution-guard`
10. `kraken-api-reconciliation`
11. `kraken-trade-journal`
12. `kraken-post-trade-review`

Always keep these available:

- `kraken-kill-switch`
- `kraken-security-permissions`
- `kraken-human-approval`
- `kraken-incident-response`

## Minimum live-trading gate

Before enabling live mode, require:

```text
30+ calendar days paper trading
100+ simulated trades, or enough observations for the strategy frequency
fees, spread, slippage, partial fills, latency, rejects, and failed cancels included
positive expectancy after costs
max drawdown below configured limit
no rule violations
all kill-switch tests passed
manual human approval recorded
API key has no withdrawal permission
only a small dedicated risk budget funded
```

## How to use this pack

If your agent platform supports Agent Skills, import each folder under `skills/`.

If your platform expects a single prompt or tool bundle, start with:

- `examples/orchestrator_prompt.md`
- `config/policy_defaults.yaml`
- `schemas/order_intent.schema.json`
- `schemas/risk_decision.schema.json`

The Python scripts are reference implementations. They are deliberately simple, local, dependency-light utilities that your agents can call or translate into your production language.

## Important implementation notes

You must connect these skills to your actual Kraken adapter carefully. The pack does not include your API keys, does not send orders, and does not call Kraken directly.

Required runtime integrations:

```text
read account equity
read balances / positions
read open orders
read recent fills
read fee tier or configured maker/taker fee assumptions
read WebSocket market data
read exchange status / connection health
place order
cancel order
cancel all orders
disable strategy
write journal event
notify human
```

The scripts accept JSON and return JSON so they can sit between your agents and your trading adapter.

## Recommended first policy

Use `config/conservative_spot_only.yaml`.

Start with one liquid pair, no leverage, no margin, small account fraction, and paper mode. Only after the system proves it can obey limits should you consider enabling a tiny live balance.

## Testing

From the root of the unzipped pack:

```bash
python scripts/validate_pack.py .
python tests/run_tests.py
```

## What this pack will not do

It will not:

- guarantee profit
- tell you which asset to buy or sell
- bypass Kraken limits
- handle your tax reporting
- eliminate exchange, liquidity, latency, model, or operational risk
- make live trading safe

It should make your agents slower, more cautious, more auditable, and less likely to do something reckless.
