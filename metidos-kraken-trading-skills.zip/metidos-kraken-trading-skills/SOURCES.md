# Sources and Design References

These were used for the pack design. Re-check the live documentation before wiring production trading.

## Agent Skills format

- Agent Skills overview: https://agentskills.io/home
- Agent Skills specification: https://agentskills.io/specification

## Kraken API references

- Kraken API global introduction: https://docs.kraken.com/api/docs/guides/global-intro/
- Kraken Spot WebSocket v2 book checksum: https://docs.kraken.com/api/docs/guides/spot-ws-book-v2/
- Kraken WebSocket v2 book channel: https://docs.kraken.com/api/docs/websocket-v2/book
- Kraken rate limits: https://support.kraken.com/articles/206548367-what-are-the-api-rate-limits-
- Kraken spot API key creation and permissions: https://support.kraken.com/articles/360000919966-how-to-create-an-api-key
- Kraken trading API overview and key-security FAQ: https://www.kraken.com/features/trading-api

## Day-trading risk references

- FINRA Day Trading: https://www.finra.org/investors/investing/investment-products/stocks/day-trading
- SEC / Investor.gov day-trading risk article: https://www.investor.gov/additional-resources/spotlight/formerdirectorlorischock-directors-take/thinking-day-trading-know-risks
- SEC Day Trading: Your Dollars at Risk: https://www.sec.gov/about/reports-publications/investorpubsdaytipshtm
