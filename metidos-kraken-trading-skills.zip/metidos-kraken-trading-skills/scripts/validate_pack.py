#!/usr/bin/env python3
"""Validate this skill pack's basic Agent Skills structure."""

from __future__ import annotations

import re
import sys
from pathlib import Path


NAME_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")


def parse_frontmatter(text: str) -> dict[str, str]:
    if not text.startswith("---\n"):
        raise ValueError("SKILL.md missing YAML frontmatter")
    end = text.find("\n---", 4)
    if end == -1:
        raise ValueError("SKILL.md frontmatter not closed")
    block = text[4:end]
    data: dict[str, str] = {}
    for line in block.splitlines():
        if ":" in line and not line.startswith(" "):
            key, value = line.split(":", 1)
            data[key.strip()] = value.strip().strip('"')
    return data


def validate(root: Path) -> list[str]:
    errors: list[str] = []
    skills_dir = root / "skills"
    if not skills_dir.exists():
        return ["missing skills/ directory"]
    for skill_dir in sorted(p for p in skills_dir.iterdir() if p.is_dir()):
        skill_md = skill_dir / "SKILL.md"
        if not skill_md.exists():
            errors.append(f"{skill_dir.name}: missing SKILL.md")
            continue
        try:
            fm = parse_frontmatter(skill_md.read_text(encoding="utf-8"))
        except Exception as exc:
            errors.append(f"{skill_dir.name}: {exc}")
            continue
        name = fm.get("name", "")
        desc = fm.get("description", "")
        if name != skill_dir.name:
            errors.append(f"{skill_dir.name}: frontmatter name {name!r} must match directory")
        if not NAME_RE.match(name):
            errors.append(f"{skill_dir.name}: invalid name {name!r}")
        if not desc:
            errors.append(f"{skill_dir.name}: missing description")
        if len(desc) > 1024:
            errors.append(f"{skill_dir.name}: description too long")
    return errors


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    errors = validate(root)
    if errors:
        print("INVALID")
        for e in errors:
            print(f"- {e}")
        return 2
    print("VALID")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
