# Review Prompts

## Daily review

```text
Summarize today's decisions.
List every rejected trade and why it was rejected.
List every rule violation.
Compute gross PnL, net PnL, fees, slippage, and drawdown.
Identify whether losses were strategy, execution, data, or discipline errors.
Recommend policy changes only if supported by evidence.
```

## Weekly review

```text
Which strategies have positive expectancy after costs?
Which strategies only work before costs?
Did the bot obey daily loss limits?
Did any agent bypass a gate?
Which symbols had unacceptable spread or slippage?
Should any strategy remain paper-only?
```
