# Design System Document: The Monolithic Intelligence

## 1. Overview & Creative North Star: "The Digital Obsidian"
This design system is engineered for the high-performance environment of an AI-integrated IDE. Our Creative North Star is **"The Digital Obsidian"**—a concept that treats the interface not as a collection of boxes, but as a single, carved block of dark matter. 

We move beyond the "standard dashboard" by embracing a high-density, editorial approach. We break the template look through **intentional asymmetry**: sidebars are slim and functional, while the code editor remains a vast, breathing canvas. By utilizing high-contrast typography scales and overlapping surface layers, we create an environment that feels authoritative, precise, and sophisticated.

---

## 2. Colors: Tonal Depth & The "No-Line" Rule
The palette is rooted in a deep, nocturnal spectrum. We use shifts in value, rather than structural lines, to define the workspace.

### Surface Hierarchy & Nesting
Instead of a flat grid, treat the UI as a series of physical layers. Each layer's depth is defined by the `surface-container` tokens:
- **Base Layer:** `surface` (#0e0e0e) – The void. Used for the furthest background.
- **Sectioning:** `surface-container-low` (#131313) – Used for primary sidebars or terminal backgrounds.
- **Active Workspace:** `surface-container` (#191a1a) – The main editor background.
- **Floating Context:** `surface-container-highest` (#262626) – Used for popovers, command palettes, and floating AI suggestions.

### The "No-Line" Rule
**Explicit Instruction:** Prohibit 1px solid borders for sectioning. Boundaries must be defined solely through background color shifts. A sidebar sitting on `surface-container-low` next to an editor on `surface-container` creates a "natural" seam that feels more premium than a hard line.

### The Glass & Gradient Rule
To prevent the UI from feeling "dead," use **Glassmorphism** for floating AI modals. Apply `surface_variant` (#262626) at 70% opacity with a `20px` backdrop blur. 
- **Signature Textures:** For Primary CTAs, use a subtle linear gradient from `primary` (#aaa4ff) to `primary_container` (#9c95f8). This adds a "lithographic" soul to the action buttons.

---

## 3. Typography: Editorial Precision
The system utilizes a tri-font strategy to separate UI controls, content, and logic.

*   **Display & Headlines (Manrope):** Used for high-level status or empty states. The wide tracking of Manrope provides an architectural feel.
*   **UI Controls & Title (Inter):** Our workhorse. Used for file trees, menus, and settings. Inter’s neutrality ensures the UI stays out of the way of the code.
*   **Labels (Space Grotesk):** Applied to `label-md` and `label-sm`. This mono-spaced influence provides a "technical" aesthetic to metadata, line numbers, and small badges.

**Hierarchy Goal:** Large `display-sm` (2.25rem) headers should feel like an editorial magazine layout when entering a new project, while `label-sm` (0.6875rem) handles the dense data of the debugger.

---

## 4. Elevation & Depth: Tonal Layering
We achieve hierarchy through "The Layering Principle" rather than traditional drop shadows.

*   **The Layering Principle:** Stack `surface-container-lowest` cards on a `surface-container-low` section to create a soft, natural lift.
*   **Ambient Shadows:** For floating elements like the Command Palette, use an extra-diffused shadow: `0 24px 48px rgba(0,0,0,0.5)`. The shadow color must be a tinted version of the surface color, never pure black.
*   **The "Ghost Border" Fallback:** If a border is required for accessibility (e.g., input focus), use the `outline_variant` (#484848) at **20% opacity**. 100% opaque borders are strictly forbidden.
*   **Glassmorphism:** AI-generated code suggestions should use a semi-transparent `surface_container_highest` with a backdrop blur to feel "projected" onto the editor.

---

## 5. Components: Precise & Compact
Components are designed for high-density information environments.

### Buttons
- **Primary:** Gradient fill (`primary` to `primary_container`), `label-md` text, `DEFAULT` (0.25rem) radius.
- **Secondary:** `surface_container_highest` fill, `on_surface` text. No border.
- **Ghost:** No fill. `primary` text. Use for low-emphasis actions like "Cancel."

### Input Fields
- **Styling:** Use `surface_container_low` for the field background. No border.
- **Focus:** A subtle `outline` (#767575) glow at 30% opacity.
- **Error:** Use `error_dim` (#d73357) for the label text and a thin underline.

### Cards & Lists
- **Rule:** Forbid divider lines. Use `spacing.3` (0.6rem) of vertical white space or a background shift to `surface_container_high` on hover to separate list items.
- **AI Suggestion Card:** Use `tertiary_container` (#fb81ae) as a very subtle 5% opacity tint to the background to signify "AI-driven" content.

### Diff States (IDE Specific)
- **Addition:** `secondary` (#d9e4e9) with a 10% green tint for the line background.
- **Deletion:** `error_container` (#a70138) at 20% opacity for the line background.

---

## 6. Do's and Don'ts

### Do:
- **Do** use `spacing.0.5` (0.1rem) for microscopic alignment in the file tree.
- **Do** use `spaceGrotesk` for all numeric data (line numbers, byte sizes).
- **Do** lean into asymmetry. A wider right-hand gutter for AI chat creates a more intentional, modern layout.

### Don't:
- **Don't** use 1px solid borders to separate the editor from the sidebar. Use the transition from `surface-container` to `surface-container-low`.
- **Don't** use pure white (#ffffff) for large blocks of text. Use `on_surface_variant` (#adabaa) for secondary descriptions to reduce eye strain.
- **Don't** use standard `rounded-lg` (0.5rem) for everything. Keep the UI "sharp" by sticking to `DEFAULT` (0.25rem) for a more professional, technical feel.