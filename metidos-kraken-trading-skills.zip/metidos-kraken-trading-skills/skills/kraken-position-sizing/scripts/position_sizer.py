#!/usr/bin/env python3
"""Conservative position sizing calculator.

Reads JSON from stdin:
{
  "account_equity": 10000,
  "side": "buy",
  "entry_price": 65000,
  "invalidation_price": 64000,
  "risk_fraction": 0.001,
  "max_notional_fraction": 0.01,
  "fee_bps": 40,
  "slippage_bps": 5
}
"""

from __future__ import annotations

import json
import sys
from decimal import Decimal, ROUND_DOWN
from typing import Any


def D(x: Any) -> Decimal:
    return Decimal(str(x))


def size_position(payload: dict[str, Any]) -> dict[str, Any]:
    reasons: list[str] = []
    equity = D(payload.get("account_equity", 0))
    side = payload.get("side")
    entry = D(payload.get("entry_price", 0))
    stop = D(payload.get("invalidation_price", 0))
    risk_fraction = D(payload.get("risk_fraction", payload.get("max_risk_per_trade_fraction", "0.001")))
    max_notional_fraction = D(payload.get("max_notional_fraction", "0.01"))
    fee_bps = D(payload.get("fee_bps", "0"))
    slippage_bps = D(payload.get("slippage_bps", "0"))
    qty_step = D(payload.get("quantity_step", "0.00000001"))

    if equity <= 0:
        reasons.append("account_equity must be > 0")
    if side not in {"buy", "sell"}:
        reasons.append("side must be buy or sell")
    if entry <= 0:
        reasons.append("entry_price must be > 0")
    if stop <= 0:
        reasons.append("invalidation_price must be > 0")
    if risk_fraction <= 0:
        reasons.append("risk_fraction must be > 0")
    if max_notional_fraction <= 0:
        reasons.append("max_notional_fraction must be > 0")
    if reasons:
        return {"sizing_ok": False, "quantity": 0, "reasons": reasons, "metrics": {}}

    if side == "buy" and stop >= entry:
        reasons.append("buy invalidation_price must be below entry_price")
    if side == "sell" and stop <= entry:
        reasons.append("sell invalidation_price must be above entry_price")
    if reasons:
        return {"sizing_ok": False, "quantity": 0, "reasons": reasons, "metrics": {}}

    raw_risk_per_unit = abs(entry - stop)
    cost_per_unit = entry * (fee_bps + slippage_bps) / Decimal("10000")
    risk_per_unit = raw_risk_per_unit + cost_per_unit
    loss_budget = equity * risk_fraction

    if risk_per_unit <= 0:
        return {"sizing_ok": False, "quantity": 0, "reasons": ["risk_per_unit must be > 0"], "metrics": {}}

    qty_by_risk = loss_budget / risk_per_unit
    max_notional = equity * max_notional_fraction
    qty_by_notional = max_notional / entry
    qty = min(qty_by_risk, qty_by_notional)

    if qty_step > 0:
        qty = (qty / qty_step).to_integral_value(rounding=ROUND_DOWN) * qty_step

    notional = qty * entry
    max_loss = qty * risk_per_unit
    clamped = qty_by_notional < qty_by_risk
    if qty <= 0:
        reasons.append("computed quantity rounds to zero")

    return {
        "sizing_ok": not reasons,
        "quantity": float(qty),
        "notional": float(notional),
        "max_loss_at_invalidation": float(max_loss),
        "risk_fraction": float(max_loss / equity) if equity > 0 else None,
        "reasons": reasons,
        "metrics": {
            "raw_risk_per_unit": float(raw_risk_per_unit),
            "estimated_cost_per_unit": float(cost_per_unit),
            "risk_per_unit_including_costs": float(risk_per_unit),
            "loss_budget": float(loss_budget),
            "max_notional": float(max_notional),
            "clamped_by_notional": clamped,
        },
    }


def main() -> int:
    payload = json.load(sys.stdin)
    result = size_position(payload)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["sizing_ok"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
