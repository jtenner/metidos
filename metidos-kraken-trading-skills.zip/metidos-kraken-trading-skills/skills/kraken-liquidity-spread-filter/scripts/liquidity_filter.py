#!/usr/bin/env python3
"""Liquidity/spread gate for an order intent.

Reads JSON from stdin. Example:
{
  "side": "buy",
  "quantity": 0.5,
  "book": {"bids": [[99, 10]], "asks": [[101, 10]]},
  "policy": {"max_spread_bps": 50, "max_slippage_bps": 20, "min_depth_to_order_notional_ratio": 5}
}
"""

from __future__ import annotations

import json
import sys
from decimal import Decimal
from typing import Any


def D(x: Any) -> Decimal:
    return Decimal(str(x))


def normalize_levels(levels: list[Any], reverse: bool) -> list[tuple[Decimal, Decimal]]:
    norm = []
    for level in levels:
        if isinstance(level, dict):
            price = level.get("price", level.get("limit_price"))
            qty = level.get("qty", level.get("quantity", level.get("order_qty")))
        else:
            price, qty = level[0], level[1]
        price_d, qty_d = D(price), D(qty)
        if price_d > 0 and qty_d > 0:
            norm.append((price_d, qty_d))
    return sorted(norm, key=lambda x: x[0], reverse=reverse)


def estimate_vwap(side: str, quantity: Decimal, bids: list[tuple[Decimal, Decimal]], asks: list[tuple[Decimal, Decimal]]) -> tuple[Decimal | None, Decimal]:
    book_side = asks if side == "buy" else bids
    remaining = quantity
    notional = Decimal("0")
    filled = Decimal("0")
    for price, qty in book_side:
        take = min(remaining, qty)
        notional += take * price
        filled += take
        remaining -= take
        if remaining <= 0:
            break
    if filled <= 0 or remaining > 0:
        return None, filled
    return notional / filled, filled


def check(payload: dict[str, Any]) -> dict[str, Any]:
    reasons: list[str] = []
    side = payload.get("side")
    if side not in {"buy", "sell"}:
        return {"liquidity_ok": False, "reasons": ["side must be buy or sell"], "metrics": {}}

    quantity = D(payload.get("quantity", 0))
    if quantity <= 0:
        return {"liquidity_ok": False, "reasons": ["quantity must be > 0"], "metrics": {}}

    book = payload.get("book", {})
    bids = normalize_levels(book.get("bids", []), reverse=True)
    asks = normalize_levels(book.get("asks", []), reverse=False)
    if not bids or not asks:
        return {"liquidity_ok": False, "reasons": ["book must include non-empty bids and asks"], "metrics": {}}

    best_bid, best_ask = bids[0][0], asks[0][0]
    if best_bid >= best_ask:
        reasons.append("crossed_or_locked_book: best_bid >= best_ask")

    mid = (best_bid + best_ask) / 2
    spread_bps = ((best_ask - best_bid) / mid) * Decimal("10000")

    policy = payload.get("policy", {})
    max_spread_bps = D(policy.get("max_spread_bps", 10))
    max_slippage_bps = D(policy.get("max_slippage_bps", 10))
    min_depth_ratio = D(policy.get("min_depth_to_order_notional_ratio", 10))

    if spread_bps > max_spread_bps:
        reasons.append(f"spread_bps {spread_bps:.6f} exceeds max {max_spread_bps}")

    vwap, filled = estimate_vwap(side, quantity, bids, asks)
    if vwap is None:
        reasons.append(f"insufficient opposing depth to fill quantity; fillable={filled}")
        estimated_slippage_bps = None
    else:
        reference = best_ask if side == "buy" else best_bid
        estimated_slippage_bps = abs((vwap - reference) / reference) * Decimal("10000")
        if estimated_slippage_bps > max_slippage_bps:
            reasons.append(f"estimated_slippage_bps {estimated_slippage_bps:.6f} exceeds max {max_slippage_bps}")

    order_notional = quantity * (best_ask if side == "buy" else best_bid)
    depth_notional = sum(p * q for p, q in (asks if side == "buy" else bids))
    required_depth = order_notional * min_depth_ratio
    if depth_notional < required_depth:
        reasons.append(f"depth_notional {depth_notional:.8f} below required {required_depth:.8f}")

    metrics = {
        "best_bid": float(best_bid),
        "best_ask": float(best_ask),
        "mid": float(mid),
        "spread_bps": float(spread_bps),
        "estimated_vwap": float(vwap) if vwap is not None else None,
        "estimated_slippage_bps": float(estimated_slippage_bps) if estimated_slippage_bps is not None else None,
        "order_notional": float(order_notional),
        "depth_notional": float(depth_notional),
        "required_depth_notional": float(required_depth),
    }
    return {"liquidity_ok": not reasons, "reasons": reasons, "metrics": metrics}


def main() -> int:
    payload = json.load(sys.stdin)
    result = check(payload)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["liquidity_ok"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
