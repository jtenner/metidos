#!/usr/bin/env python3
"""Small dependency-free indicator helpers for research.

This is for hypothesis testing and feature generation, not a source of live trade recommendations.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Iterable


def D(x) -> Decimal:
    return Decimal(str(x))


def sma(values: Iterable[float | int | str], window: int) -> list[float | None]:
    vals = [D(v) for v in values]
    out: list[float | None] = []
    running = Decimal("0")
    for i, v in enumerate(vals):
        running += v
        if i >= window:
            running -= vals[i - window]
        out.append(float(running / window) if i >= window - 1 else None)
    return out


def ema(values: Iterable[float | int | str], window: int) -> list[float | None]:
    vals = [D(v) for v in values]
    if not vals:
        return []
    alpha = Decimal("2") / Decimal(window + 1)
    out: list[float | None] = []
    prev = vals[0]
    for i, v in enumerate(vals):
        prev = v if i == 0 else alpha * v + (Decimal("1") - alpha) * prev
        out.append(float(prev) if i >= window - 1 else None)
    return out


def true_range(high, low, prev_close) -> Decimal:
    h, l, pc = D(high), D(low), D(prev_close)
    return max(h - l, abs(h - pc), abs(l - pc))


def atr(candles: list[dict], window: int) -> list[float | None]:
    if not candles:
        return []
    trs = []
    prev_close = D(candles[0]["close"])
    for c in candles:
        tr = true_range(c["high"], c["low"], prev_close)
        trs.append(tr)
        prev_close = D(c["close"])
    return sma([str(x) for x in trs], window)


def rsi(closes: Iterable[float | int | str], window: int = 14) -> list[float | None]:
    vals = [D(v) for v in closes]
    if len(vals) < 2:
        return [None] * len(vals)
    gains = [Decimal("0")]
    losses = [Decimal("0")]
    for i in range(1, len(vals)):
        change = vals[i] - vals[i - 1]
        gains.append(max(change, Decimal("0")))
        losses.append(max(-change, Decimal("0")))
    out: list[float | None] = []
    for i in range(len(vals)):
        if i < window:
            out.append(None)
            continue
        avg_gain = sum(gains[i - window + 1 : i + 1]) / window
        avg_loss = sum(losses[i - window + 1 : i + 1]) / window
        if avg_loss == 0:
            out.append(100.0)
        else:
            rs = avg_gain / avg_loss
            out.append(float(Decimal("100") - (Decimal("100") / (Decimal("1") + rs))))
    return out
