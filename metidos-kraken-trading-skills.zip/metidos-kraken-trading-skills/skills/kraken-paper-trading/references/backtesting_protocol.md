# Backtesting and Paper-Trading Protocol

## Split data

Use at least:

```text
development sample
validation sample
out-of-sample sample
recent paper sample
```

Never choose parameters by looking at the out-of-sample result.

## Cost stress test

Run each strategy under:

```text
normal fee assumption
2x fee assumption
normal slippage assumption
2x slippage assumption
missed-fill scenario
high-volatility scenario
low-liquidity scenario
```

## False-discovery control

The more strategies you test, the more likely one looks good by luck. Keep a register of every tested idea, including failures.

## Paper/live gap

If paper trading assumes fills that live trading cannot achieve, the strategy is not live-approved.
