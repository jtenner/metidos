# Live Trading Approval Card

## Summary

- Strategy:
- Symbol:
- Side:
- Mode:
- Requested action:

## Risk

- Account equity:
- Proposed notional:
- Risk at invalidation:
- Risk fraction:
- Daily realized PnL:
- Daily loss limit:
- Current open positions:
- Current open orders:

## Trade plan

- Entry:
- Invalidation:
- Exit:
- Time stop:
- Do-not-trade conditions:

## Evidence

- Paper days:
- Paper trades:
- Net expectancy after costs:
- Max drawdown:
- Worst losing streak:
- Fee/slippage stress result:

## Operations

- API key has withdrawal permission? Must be no.
- Market data checksum healthy?
- Kill switch tested?
- Reconciliation healthy?
- Journal path:

## Decision

```text
Approve live trade? yes/no
Approval expires at:
Human approver:
```
