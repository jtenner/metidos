#!/usr/bin/env python3
"""Validate an adapter-neutral order intent before execution."""

from __future__ import annotations

import json
import sys
from typing import Any


REQUIRED = [
    "intent_id",
    "strategy_id",
    "symbol",
    "side",
    "order_type",
    "quantity",
    "invalidation_price",
    "time_in_force",
    "client_order_id",
    "mode",
]


def validate(payload: dict[str, Any]) -> dict[str, Any]:
    intent = payload.get("order_intent", payload)
    policy = payload.get("policy", {})
    reasons: list[str] = []

    for key in REQUIRED:
        if key not in intent or intent[key] in (None, ""):
            reasons.append(f"missing required field: {key}")

    if intent.get("side") not in {"buy", "sell"}:
        reasons.append("side must be buy or sell")

    order_type = intent.get("order_type")
    allowed_order_types = set(policy.get("allowed_order_types", policy.get("orders", {}).get("allowed_order_types", ["limit"])))
    if order_type not in allowed_order_types:
        reasons.append(f"order_type {order_type!r} not allowed")

    if order_type == "market" and not bool(policy.get("allow_market_orders", policy.get("orders", {}).get("allow_market_orders", False))):
        reasons.append("market orders are disabled")

    if order_type == "limit" and not intent.get("limit_price"):
        reasons.append("limit orders require limit_price")

    if intent.get("mode") == "live" and not bool(policy.get("live_trading_enabled", False)):
        reasons.append("live trading disabled by policy")

    if bool(policy.get("require_client_order_id", policy.get("orders", {}).get("require_client_order_id", True))) and not intent.get("client_order_id"):
        reasons.append("client_order_id required")

    if intent.get("post_only") is False and bool(intent.get("maker_fee_assumption_used", False)):
        reasons.append("post_only required when maker fee assumption is used")

    try:
        qty = float(intent.get("quantity", 0))
        if qty <= 0:
            reasons.append("quantity must be > 0")
    except Exception:
        reasons.append("quantity must be numeric")

    try:
        stop = float(intent.get("invalidation_price", 0))
        if stop <= 0:
            reasons.append("invalidation_price must be > 0")
    except Exception:
        reasons.append("invalidation_price must be numeric")

    return {
        "execution_intent_valid": not reasons,
        "reasons": reasons,
        "normalized_intent": intent if not reasons else None,
    }


def main() -> int:
    payload = json.load(sys.stdin)
    result = validate(payload)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["execution_intent_valid"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
