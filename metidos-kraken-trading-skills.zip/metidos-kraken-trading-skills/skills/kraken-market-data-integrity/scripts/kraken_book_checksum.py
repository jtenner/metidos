#!/usr/bin/env python3
"""Reference Kraken Spot WebSocket v2 L2 book checksum calculator.

Input JSON shape:
{
  "asks": [{"price": "45285.2", "qty": "0.00100000"}, ...],
  "bids": [{"price": "45283.5", "qty": "0.10000000"}, ...],
  "checksum": 3310070434
}

This preserves decimal precision by treating price/qty as strings.
"""

from __future__ import annotations

import argparse
import json
import sys
import zlib
from decimal import Decimal
from typing import Any, Iterable


def _as_decimal_str(value: Any) -> str:
    """Return a plain decimal string without scientific notation."""
    if isinstance(value, str):
        return value
    return format(Decimal(str(value)), "f")


def _format_component(value: Any) -> str:
    s = _as_decimal_str(value)
    s = s.replace(".", "")
    s = s.lstrip("0")
    return s or "0"


def _level_string(level: dict[str, Any]) -> str:
    price = level.get("price", level.get("limit_price"))
    qty = level.get("qty", level.get("order_qty"))
    if price is None or qty is None:
        raise ValueError(f"level missing price/qty fields: {level!r}")
    return _format_component(price) + _format_component(qty)


def checksum_string(asks: Iterable[dict[str, Any]], bids: Iterable[dict[str, Any]]) -> str:
    asks_sorted = sorted(list(asks), key=lambda x: Decimal(_as_decimal_str(x.get("price", x.get("limit_price")))))[:10]
    bids_sorted = sorted(list(bids), key=lambda x: Decimal(_as_decimal_str(x.get("price", x.get("limit_price")))), reverse=True)[:10]
    return "".join(_level_string(level) for level in asks_sorted) + "".join(_level_string(level) for level in bids_sorted)


def checksum(asks: Iterable[dict[str, Any]], bids: Iterable[dict[str, Any]]) -> int:
    data = checksum_string(asks, bids).encode("ascii")
    return zlib.crc32(data) & 0xFFFFFFFF


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--show-string", action="store_true")
    args = parser.parse_args()

    payload = json.load(sys.stdin)
    asks = payload.get("asks") or payload.get("data", [{}])[0].get("asks", [])
    bids = payload.get("bids") or payload.get("data", [{}])[0].get("bids", [])
    computed = checksum(asks, bids)
    out = {"checksum": computed}

    expected = payload.get("checksum")
    if expected is None and payload.get("data"):
        expected = payload["data"][0].get("checksum")
    if expected is not None:
        out["expected"] = int(expected)
        out["matches"] = computed == int(expected)
    if args.show_string:
        out["checksum_string"] = checksum_string(asks, bids)

    print(json.dumps(out, indent=2, sort_keys=True))
    return 0 if out.get("matches", True) else 2


if __name__ == "__main__":
    raise SystemExit(main())
