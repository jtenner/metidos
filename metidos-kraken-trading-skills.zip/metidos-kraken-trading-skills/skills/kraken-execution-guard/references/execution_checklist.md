# Execution Checklist

Before submit:

```text
[ ] risk approval references same intent_id
[ ] market data approval references same intent_id
[ ] liquidity approval references same intent_id
[ ] edge approval references same intent_id
[ ] client_order_id unique
[ ] order type allowed
[ ] time-in-force allowed
[ ] no active kill switch
[ ] no stale open order collision
[ ] free balance sufficient
```

After submit:

```text
[ ] exchange acknowledged order
[ ] order id captured
[ ] local state updated
[ ] open orders fetched
[ ] fill stream monitored
[ ] journal entry written
```

On reject/error:

```text
[ ] classify error
[ ] do not retry blindly
[ ] check whether order may actually exist
[ ] reconcile before resubmitting
```
