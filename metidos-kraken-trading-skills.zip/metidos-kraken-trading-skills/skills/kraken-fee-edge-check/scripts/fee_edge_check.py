#!/usr/bin/env python3
"""Fee/edge gate. Reads JSON from stdin and returns JSON."""

from __future__ import annotations

import json
import sys
from decimal import Decimal
from typing import Any


def D(x: Any, default: str = "0") -> Decimal:
    if x is None:
        return Decimal(default)
    return Decimal(str(x))


def check(payload: dict[str, Any]) -> dict[str, Any]:
    reasons: list[str] = []
    expected_edge_bps = D(payload.get("expected_edge_bps"))
    multiple = D(payload.get("minimum_expected_edge_multiple_of_total_cost", payload.get("policy", {}).get("minimum_expected_edge_multiple_of_total_cost", "2")))

    components = payload.get("cost_components_bps", {})
    round_trip_cost_bps = sum(D(v) for v in components.values())
    if not components:
        round_trip_cost_bps = (
            D(payload.get("entry_fee_bps"))
            + D(payload.get("exit_fee_bps"))
            + D(payload.get("entry_spread_cost_bps"))
            + D(payload.get("exit_spread_cost_bps"))
            + D(payload.get("entry_slippage_bps"))
            + D(payload.get("exit_slippage_bps"))
            + D(payload.get("latency_buffer_bps"))
        )

    required_edge_bps = round_trip_cost_bps * multiple

    if expected_edge_bps <= 0:
        reasons.append("expected_edge_bps must be provided and > 0")
    if round_trip_cost_bps <= 0:
        reasons.append("round_trip_cost_bps must be estimated and > 0")
    if expected_edge_bps < required_edge_bps:
        reasons.append(f"expected_edge_bps {expected_edge_bps} below required_edge_bps {required_edge_bps}")

    return {
        "edge_ok": not reasons,
        "reasons": reasons,
        "metrics": {
            "expected_edge_bps": float(expected_edge_bps),
            "round_trip_cost_bps": float(round_trip_cost_bps),
            "minimum_multiple": float(multiple),
            "required_edge_bps": float(required_edge_bps),
        },
    }


def main() -> int:
    payload = json.load(sys.stdin)
    result = check(payload)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["edge_ok"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
