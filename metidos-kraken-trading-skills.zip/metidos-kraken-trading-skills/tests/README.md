# Tests

Run from the pack root:

```bash
python tests/run_tests.py
```

The tests validate the folder structure and sanity-check the reference scripts.
