# Market Data Runbook

## On startup

1. Connect WebSocket.
2. Subscribe to book with configured depth.
3. Wait for snapshot.
4. Initialize local book from snapshot.
5. Verify checksum.
6. Mark symbol trade-eligible only after a clean checksum.

## On update

1. Apply all bid and ask changes in the update.
2. Remove levels with zero quantity.
3. Sort asks low-to-high and bids high-to-low.
4. Truncate to subscribed depth.
5. Verify checksum if present.
6. Update book timestamp.
7. Publish best bid/ask and depth metrics.

## On reconnect

1. Set `market_data_ok = false`.
2. Cancel stale trade decisions.
3. Resubscribe.
4. Wait for fresh snapshot.
5. Verify checksum.
6. Require a new trade signal.
