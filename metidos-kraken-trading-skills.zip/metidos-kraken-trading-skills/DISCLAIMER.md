# Disclaimer

This pack is educational infrastructure for agent behavior and trading operations. It is not investment, financial, legal, tax, or accounting advice.

Day trading and crypto trading can produce rapid losses. Automated trading adds additional failure modes: stale data, API outages, latency, partial fills, failed cancels, incorrect position state, software bugs, model mistakes, and prompt-injection vulnerabilities.

Use only money you can afford to lose. Do not use rent, debt, tuition, emergency savings, retirement funds, borrowed funds, or money needed for ordinary living expenses.

The safest configuration is paper mode. The second safest configuration is no trading. The pack intentionally causes agents to reject many trades.
