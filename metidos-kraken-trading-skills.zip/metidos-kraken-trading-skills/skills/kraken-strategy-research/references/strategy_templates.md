# Strategy Templates

These templates are not recommendations. They are research starting points.

## Template: Trend pullback

```yaml
strategy_id: trend_pullback_v1
regime:
  higher_timeframe: 15m
  trend_rule: "EMA fast > EMA slow and slope positive"
entry:
  timeframe: 1m
  condition: "pullback to EMA area, then close back above trigger"
invalidation:
  rule: "below pullback swing low or ATR-based stop"
exit:
  rule: "partial at 1R, remainder trails under structure"
do_not_trade:
  - "spread wider than policy"
  - "book checksum failed"
  - "ATR spike exceeds max volatility"
  - "daily loss limit near breach"
```

## Template: VWAP mean reversion

```yaml
strategy_id: vwap_reversion_v1
regime:
  condition: "range-bound; no strong higher-timeframe trend"
entry:
  condition: "price extends N ATR below VWAP then stabilizes"
invalidation:
  rule: "new impulse low by more than configured threshold"
exit:
  rule: "return to VWAP band or time stop"
do_not_trade:
  - "trend regime"
  - "news shock"
  - "thin book"
```

## Template: Opening range breakout for 24/7 crypto sessions

Crypto has no equity-style open, so define a synthetic session.

```yaml
strategy_id: synthetic_range_breakout_v1
session_anchor: "00:00 UTC or chosen liquid window"
range_window_minutes: 60
entry:
  condition: "break and hold above range high with liquidity confirmation"
invalidation:
  rule: "back inside range or ATR stop"
exit:
  rule: "trailing stop or fixed R multiple"
```

## Research warnings

Any strategy with many tunable parameters should be presumed overfit until proven otherwise.
