#!/usr/bin/env python3
"""Tiny reference paper broker.

This is not a production simulator. It demonstrates how an agent can model:
- limit fills against bid/ask ticks
- fees
- simple stop/invalidation exits
- partial/no-fill outcomes

Input JSON:
{
  "cash": 10000,
  "fee_bps": 40,
  "order": {
    "side": "buy",
    "quantity": 0.1,
    "limit_price": 100,
    "invalidation_price": 95
  },
  "ticks": [
    {"bid": 99, "ask": 101, "timestamp": "..."},
    {"bid": 100, "ask": 100.5, "timestamp": "..."}
  ]
}
"""

from __future__ import annotations

import json
import sys
from decimal import Decimal
from typing import Any


def D(x: Any) -> Decimal:
    return Decimal(str(x))


def simulate(payload: dict[str, Any]) -> dict[str, Any]:
    cash = D(payload.get("cash", 0))
    fee_bps = D(payload.get("fee_bps", 0))
    order = payload["order"]
    ticks = payload.get("ticks", [])

    side = order["side"]
    qty = D(order["quantity"])
    limit_price = D(order["limit_price"])
    invalidation = D(order["invalidation_price"])

    filled = Decimal("0")
    avg_price = Decimal("0")
    fee_paid = Decimal("0")
    events = []

    for tick in ticks:
        bid = D(tick["bid"])
        ask = D(tick["ask"])
        ts = tick.get("timestamp")
        fill_price = None

        if side == "buy" and ask <= limit_price:
            fill_price = ask
        elif side == "sell" and bid >= limit_price:
            fill_price = bid

        if fill_price is not None:
            # Simplified full fill. Production simulators should model depth and queue position.
            filled = qty
            avg_price = fill_price
            fee_paid = qty * fill_price * fee_bps / Decimal("10000")
            cash_change = -(qty * fill_price + fee_paid) if side == "buy" else (qty * fill_price - fee_paid)
            cash += cash_change
            events.append({"type": "fill", "timestamp": ts, "price": float(fill_price), "quantity": float(qty), "fee": float(fee_paid)})
            break

    status = "unfilled" if filled == 0 else "filled"
    unrealized_stop_loss = None
    if filled > 0:
        if side == "buy":
            unrealized_stop_loss = (avg_price - invalidation) * filled + fee_paid
        else:
            unrealized_stop_loss = (invalidation - avg_price) * filled + fee_paid

    return {
        "status": status,
        "filled_quantity": float(filled),
        "average_fill_price": float(avg_price) if filled else None,
        "fee_paid": float(fee_paid),
        "cash_after": float(cash),
        "max_loss_at_invalidation": float(unrealized_stop_loss) if unrealized_stop_loss is not None else None,
        "events": events,
        "warnings": [
            "Reference simulator only; production paper trading must model spread, depth, queue position, latency, partial fills, failed cancels, and exchange-specific behavior."
        ],
    }


def main() -> int:
    payload = json.load(sys.stdin)
    result = simulate(payload)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
