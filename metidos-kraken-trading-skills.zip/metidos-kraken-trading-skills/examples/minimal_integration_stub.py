#!/usr/bin/env python3
"""Minimal adapter-neutral flow.

This does not call Kraken. Wire your own adapter behind these methods.
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def run_json(script: Path, payload: dict) -> dict:
    proc = subprocess.run(
        [sys.executable, str(script)],
        input=json.dumps(payload),
        text=True,
        capture_output=True,
        check=False,
    )
    if proc.stdout:
        result = json.loads(proc.stdout)
    else:
        result = {"error": proc.stderr}
    return result


def main() -> int:
    payload = json.loads((ROOT / "examples" / "sample_risk_gate_payload.json").read_text())
    risk = run_json(ROOT / "skills" / "kraken-risk-manager" / "scripts" / "risk_gate.py", payload)
    print(json.dumps({"risk_decision": risk}, indent=2))

    if not risk.get("approved"):
        print("Rejected by risk gate; no execution attempted.")
        return 0

    # Your adapter would only be called here, after all gates:
    # adapter.place_limit_order(payload["order_intent"])
    print("Would submit in paper adapter only.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
