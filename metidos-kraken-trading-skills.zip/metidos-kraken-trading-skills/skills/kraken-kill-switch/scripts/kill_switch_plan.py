#!/usr/bin/env python3
"""Generate a kill-switch action plan from state."""

from __future__ import annotations

import json
import sys
from typing import Any


CRITICAL_FLAGS = [
    "daily_loss_limit_hit",
    "weekly_loss_limit_hit",
    "unknown_open_order",
    "unexpected_position",
    "state_mismatch",
    "checksum_failure",
    "failed_cancel",
    "repeated_api_errors",
    "human_panic",
    "kill_switch_latched",
]


def plan(payload: dict[str, Any]) -> dict[str, Any]:
    reasons = []
    for flag in CRITICAL_FLAGS:
        if payload.get(flag):
            reasons.append(flag)

    # Numeric drawdown trigger convenience.
    equity = float(payload.get("equity", 0) or 0)
    daily_pnl = float(payload.get("daily_realized_pnl", 0) or 0)
    max_daily_loss_fraction = float(payload.get("max_daily_loss_fraction", 0) or 0)
    if equity > 0 and max_daily_loss_fraction > 0 and daily_pnl <= -(equity * max_daily_loss_fraction):
        reasons.append("daily_loss_limit_hit_by_pnl")

    triggered = bool(reasons)
    actions = []
    if triggered:
        actions = [
            "disable_new_orders",
            "cancel_all_orders",
            "fetch_open_orders",
            "fetch_balances_and_positions",
            "write_incident_journal_entry",
            "notify_human",
            "require_manual_reset",
        ]

    return {
        "kill_switch": triggered,
        "reasons": sorted(set(reasons)),
        "actions": actions,
        "requires_manual_reset": triggered,
    }


def main() -> int:
    payload = json.load(sys.stdin)
    result = plan(payload)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 2 if result["kill_switch"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
