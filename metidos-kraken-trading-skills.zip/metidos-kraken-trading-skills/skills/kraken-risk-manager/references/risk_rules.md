# Risk Rules

## Sizing by invalidation

The stop/invalidation price is not optional. Without it, the system cannot know the trade's downside.

## Risk fraction bands

For experimental agent trading:

```text
0.05% equity risk per trade: very conservative live test
0.10% equity risk per trade: small live test
0.25% equity risk per trade: aggressive for bots
1.00% equity risk per trade: high risk; avoid unless highly validated
```

## Daily stop

The daily stop protects the trader from model drift, bad market regimes, and revenge-trading loops. Once hit, the bot should not resume automatically.

## Correlation

Crypto pairs often become highly correlated during stress. Do not treat BTC/USD, ETH/USD, SOL/USD, and similar pairs as independent risk buckets during broad market shocks.
