#!/usr/bin/env python3
"""Compare local and exchange state.

Reads:
{
  "local": {"open_orders": [...], "positions": [...]},
  "exchange": {"open_orders": [...], "positions": [...]}
}
"""

from __future__ import annotations

import json
import sys
from typing import Any


def _id(order: dict[str, Any]) -> str:
    return str(order.get("order_id") or order.get("id") or order.get("txid") or order.get("client_order_id"))


def _symbol_position_key(pos: dict[str, Any]) -> str:
    return str(pos.get("symbol") or pos.get("pair") or pos.get("asset"))


def compare(payload: dict[str, Any]) -> dict[str, Any]:
    local = payload.get("local", {})
    exchange = payload.get("exchange", {})
    differences: list[str] = []
    actions: list[str] = []

    local_orders = {_id(o): o for o in local.get("open_orders", []) if _id(o) != "None"}
    exch_orders = {_id(o): o for o in exchange.get("open_orders", []) if _id(o) != "None"}

    for oid in sorted(local_orders.keys() - exch_orders.keys()):
        differences.append(f"local open order missing on exchange: {oid}")
        actions.append("inspect recent fills/cancels before new orders")
    for oid in sorted(exch_orders.keys() - local_orders.keys()):
        differences.append(f"exchange has unknown open order: {oid}")
        actions.append("cancel unknown order or adopt into local state after human review")

    local_pos = {_symbol_position_key(p): p for p in local.get("positions", []) if _symbol_position_key(p) != "None"}
    exch_pos = {_symbol_position_key(p): p for p in exchange.get("positions", []) if _symbol_position_key(p) != "None"}

    for sym in sorted(set(local_pos) | set(exch_pos)):
        lq = float(local_pos.get(sym, {}).get("quantity", local_pos.get(sym, {}).get("qty", 0)) or 0)
        eq = float(exch_pos.get(sym, {}).get("quantity", exch_pos.get(sym, {}).get("qty", 0)) or 0)
        tolerance = float(payload.get("position_tolerance", 1e-12))
        if abs(lq - eq) > tolerance:
            differences.append(f"position mismatch for {sym}: local={lq} exchange={eq}")
            actions.append("halt and reconcile balances/positions")

    severity = "ok" if not differences else "critical"
    return {
        "reconciled": not differences,
        "severity": severity,
        "differences": differences,
        "required_actions": sorted(set(actions)),
    }


def main() -> int:
    payload = json.load(sys.stdin)
    result = compare(payload)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["reconciled"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
