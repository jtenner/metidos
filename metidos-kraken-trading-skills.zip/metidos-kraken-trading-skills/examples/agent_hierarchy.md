# Agent Hierarchy

```mermaid
flowchart TD
    U[Human / Scheduler] --> G[Governance Agent]
    G --> R[Research Agent]
    R --> P[Paper Trading Agent]
    P --> M[Market Data Integrity Agent]
    M --> L[Liquidity / Spread Filter]
    L --> S[Position Sizer]
    S --> RM[Risk Manager]
    RM --> F[Fee / Edge Check]
    F --> H{Human approval?}
    H --> E[Execution Guard]
    E --> A[Kraken Adapter]
    A --> C[Reconciliation Agent]
    C --> J[Trade Journal]
    J --> V[Post-Trade Review]
    K[Kill Switch] --> A
    K --> J
```

The strategy/research path has no direct edge to the adapter.
