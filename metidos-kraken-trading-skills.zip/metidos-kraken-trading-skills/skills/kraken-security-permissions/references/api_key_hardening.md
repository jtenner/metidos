# API Key Hardening

## Minimal permission model

The bot needs to query state and manage orders. It does not need withdrawal permission.

## Key rotation

Rotate keys after:

```text
debug logs accidentally include auth fields
machine compromise suspected
agent prompt included secret
developer copied key into chat
employee or contractor access changes
```

## Environment variables

Example names:

```text
KRAKEN_API_KEY_READONLY
KRAKEN_API_SECRET_READONLY
KRAKEN_API_KEY_TRADING
KRAKEN_API_SECRET_TRADING
```

Do not let agents print environment variables.
