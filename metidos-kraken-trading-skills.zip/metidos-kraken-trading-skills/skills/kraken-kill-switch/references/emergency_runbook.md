# Emergency Runbook

## First priority

Prevent additional unintended exposure.

## Second priority

Establish the truth:

```text
What orders are open at the exchange?
What positions/balances exist at the exchange?
What fills happened recently?
What did the bot believe before the incident?
```

## Third priority

Preserve evidence:

```text
journal
logs
adapter responses
policy file
account snapshot
open orders
fills
agent messages
```

## Do not

- resume automatically
- retry unknown failed orders blindly
- let the strategy agent explain away the incident
- edit journal history
- increase size to recover
