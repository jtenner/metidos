# Kraken API Key Checklist

Before any live deployment:

```text
[ ] Separate read-only and trading keys.
[ ] No key has withdrawal permission.
[ ] Trading key is restricted by IP if your infrastructure supports stable egress IPs.
[ ] Key expiration is considered for experiments.
[ ] Key is stored in a secrets manager, not in prompts or files.
[ ] Bot can query open orders and trades.
[ ] Bot can cancel/close orders.
[ ] Bot can modify orders only if your execution policy allows it.
[ ] Emergency cancel-all path is tested.
[ ] Rotating the key does not require editing agent prompts.
[ ] Logs redact public key, private key, bearer tokens, auth headers, cookies, and signatures.
```

For third-party or agent trading, the key should not need funding or withdrawal permissions.
