# Error Taxonomy

## Strategy errors

- false signal
- wrong regime
- invalid stop placement
- target unrealistic after costs

## Execution errors

- market order used against policy
- stale limit price
- order chased
- duplicate order
- missing client id
- failed cancellation not handled

## Data errors

- stale book
- checksum mismatch
- missed WebSocket update
- wrong symbol
- bad fee assumption

## Discipline errors

- daily stop ignored
- size increased after loss
- human approval skipped
- journal missing
