#!/usr/bin/env python3
"""Lightweight tests for reference scripts."""

from __future__ import annotations

import importlib.util
import json
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def load(path: Path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def run_script(path: Path, payload: dict) -> tuple[int, dict]:
    proc = subprocess.run(
        [sys.executable, str(path)],
        input=json.dumps(payload),
        text=True,
        capture_output=True,
        check=False,
    )
    out = json.loads(proc.stdout) if proc.stdout else {}
    return proc.returncode, out


def test_pack_validator():
    code, out_text = subprocess.getstatusoutput(f"{sys.executable} {ROOT / 'scripts' / 'validate_pack.py'} {ROOT}")
    assert code == 0, out_text


def test_kraken_checksum_sample():
    mod = load(ROOT / "skills" / "kraken-market-data-integrity" / "scripts" / "kraken_book_checksum.py")
    sample = {
       "bids": [
          {"price": "45283.5", "qty": "0.10000000"},
          {"price": "45283.4", "qty": "1.54582015"},
          {"price": "45282.1", "qty": "0.10000000"},
          {"price": "45281.0", "qty": "0.10000000"},
          {"price": "45280.3", "qty": "1.54592586"},
          {"price": "45279.0", "qty": "0.07990000"},
          {"price": "45277.6", "qty": "0.03310103"},
          {"price": "45277.5", "qty": "0.30000000"},
          {"price": "45277.3", "qty": "1.54602737"},
          {"price": "45276.6", "qty": "0.15445238"}
       ],
       "asks": [
          {"price": "45285.2", "qty": "0.00100000"},
          {"price": "45286.4", "qty": "1.54571953"},
          {"price": "45286.6", "qty": "1.54571109"},
          {"price": "45289.6", "qty": "1.54560911"},
          {"price": "45290.2", "qty": "0.15890660"},
          {"price": "45291.8", "qty": "1.54553491"},
          {"price": "45294.7", "qty": "0.04454749"},
          {"price": "45296.1", "qty": "0.35380000"},
          {"price": "45297.5", "qty": "0.09945542"},
          {"price": "45299.5", "qty": "0.18772827"}
       ],
       "checksum": 3310070434
    }
    assert mod.checksum(sample["asks"], sample["bids"]) == sample["checksum"]


def test_position_sizer():
    mod = load(ROOT / "skills" / "kraken-position-sizing" / "scripts" / "position_sizer.py")
    res = mod.size_position({
        "account_equity": 10000,
        "side": "buy",
        "entry_price": 100,
        "invalidation_price": 95,
        "risk_fraction": 0.001,
        "max_notional_fraction": 0.1,
        "fee_bps": 10,
        "slippage_bps": 5,
        "quantity_step": 0.000001,
    })
    assert res["sizing_ok"], res
    assert res["max_loss_at_invalidation"] <= 10.01


def test_risk_gate_rejects_large():
    mod = load(ROOT / "skills" / "kraken-risk-manager" / "scripts" / "risk_gate.py")
    payload = json.loads((ROOT / "examples" / "sample_risk_gate_payload.json").read_text())
    payload["order_intent"]["quantity"] = 10
    res = mod.risk_gate(payload)
    assert not res["approved"]
    assert any("risk_fraction" in r or "position_notional" in r for r in res["reasons"])


def test_liquidity_filter():
    mod = load(ROOT / "skills" / "kraken-liquidity-spread-filter" / "scripts" / "liquidity_filter.py")
    res = mod.check({
        "side": "buy",
        "quantity": 0.1,
        "book": {"bids": [[99, 10]], "asks": [[101, 10]]},
        "policy": {"max_spread_bps": 300, "max_slippage_bps": 50, "min_depth_to_order_notional_ratio": 1}
    })
    assert res["liquidity_ok"], res


def test_execution_validator_rejects_live_disabled():
    mod = load(ROOT / "skills" / "kraken-execution-guard" / "scripts" / "order_intent_validator.py")
    intent = json.loads((ROOT / "examples" / "sample_order_intent.json").read_text())
    intent["mode"] = "live"
    res = mod.validate({"order_intent": intent, "policy": {"live_trading_enabled": False, "allowed_order_types": ["limit"]}})
    assert not res["execution_intent_valid"]
    assert any("live trading disabled" in r for r in res["reasons"])


def test_reconciliation_detects_unknown_order():
    mod = load(ROOT / "skills" / "kraken-api-reconciliation" / "scripts" / "reconcile_state.py")
    res = mod.compare({
        "local": {"open_orders": []},
        "exchange": {"open_orders": [{"order_id": "O-UNKNOWN"}]},
    })
    assert not res["reconciled"]
    assert res["severity"] == "critical"


def run_all():
    tests = [name for name in globals() if name.startswith("test_")]
    failures = []
    for name in tests:
        try:
            globals()[name]()
            print(f"PASS {name}")
        except Exception as exc:
            failures.append((name, exc))
            print(f"FAIL {name}: {exc}")
    if failures:
        raise SystemExit(1)
    print(f"All {len(tests)} tests passed.")


if __name__ == "__main__":
    run_all()
