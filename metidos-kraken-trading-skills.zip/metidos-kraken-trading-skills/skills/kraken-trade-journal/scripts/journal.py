#!/usr/bin/env python3
"""Append-only JSONL journal utility with secret redaction.

Usage:
  echo '{"event_type":"test","mode":"paper","agent":"tester","summary":"hello"}' |
    python journal.py --path journal.jsonl
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


SECRET_MARKERS = ("secret", "private", "token", "password", "signature", "cookie", "authorization", "api_key", "apikey")


def redact(obj: Any) -> Any:
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if any(marker in str(k).lower() for marker in SECRET_MARKERS):
                out[k] = "[REDACTED]"
            else:
                out[k] = redact(v)
        return out
    if isinstance(obj, list):
        return [redact(x) for x in obj]
    return obj


def stable_hash(obj: Any) -> str:
    data = json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(data).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--path", required=True)
    args = parser.parse_args()

    entry = json.load(sys.stdin)
    entry = redact(entry)
    entry.setdefault("timestamp", datetime.now(timezone.utc).isoformat())
    entry.setdefault("mode", "unknown")
    entry.setdefault("agent", "unknown")
    entry.setdefault("event_type", "unknown")
    entry.setdefault("summary", "")
    entry.setdefault("rule_violations", [])
    entry["entry_hash"] = stable_hash(entry)

    path = Path(args.path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry, sort_keys=True) + "\n")

    print(json.dumps({"journal_path": str(path), "entry_hash": entry["entry_hash"]}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
