# Install / Import Notes

## Option A: Agent Skills-compatible runtime

Import the folders under:

```text
skills/
```

Each skill is a directory with a `SKILL.md` file and optional `scripts/`, `references/`, and `assets/` files.

## Option B: Metidos custom agent runtime

If Metidos has its own skill format, map each skill as follows:

```text
SKILL.md frontmatter.name        -> skill id
SKILL.md frontmatter.description -> activation / routing description
SKILL.md body                    -> main agent instructions
references/*.md                  -> long-form reference material
scripts/*.py                     -> callable local tools or examples
assets/*                         -> prompts/templates/config snippets
```

## Option C: Single-agent prompt

Use:

```text
examples/orchestrator_prompt.md
```

Then attach or paste:

```text
config/policy_defaults.yaml
schemas/*.schema.json
```

## Secrets

Never put Kraken API keys inside the skill files, prompts, logs, screenshots, notebooks, or agent memory.

Use environment variables or a secrets manager. Give trading agents the minimum permissions needed. Do not enable withdrawals.

## Live trading enablement

The pack ships with live trading disabled. To enable it in your own runtime, you should require all of the following:

```text
policy.live_trading_enabled = true
policy.human_approval_required_for_live = true
policy.allow_withdrawals = false
policy.allow_leverage = false unless explicitly and separately approved
policy.max_daily_loss_fraction configured
policy.max_risk_per_trade_fraction configured
paper-trading gate passed
kill-switch test passed
exchange-state reconciliation test passed
```

## Runtime contract

Every proposed trade should be represented as an `order_intent` JSON object and then passed through:

```text
market data integrity check
liquidity/spread check
position sizing check
risk gate
fee/edge check
execution guard
journal append
reconciliation
```

Do not let strategy agents call your Kraken order-placement adapter directly.
